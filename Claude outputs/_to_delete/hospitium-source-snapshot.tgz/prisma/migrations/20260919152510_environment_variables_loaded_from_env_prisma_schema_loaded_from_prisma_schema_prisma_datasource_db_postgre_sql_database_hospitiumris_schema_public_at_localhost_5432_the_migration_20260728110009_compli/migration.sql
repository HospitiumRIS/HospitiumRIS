-- AlterTable
ALTER TABLE "public"."institutions" ALTER COLUMN "enabledModules" SET DEFAULT '["publications","projects","clinical_trials","image_integrity","training","administration","analytics"]';
