# HospitiumRIS

A comprehensive Research Information System designed for researchers, institutions, and funding foundations. HospitiumRIS streamlines research management by providing tools for publication tracking, collaborative manuscript editing, proposal management, and integration with major academic databases.

## Overview

HospitiumRIS serves as a centralized platform for:

- **Researchers** to manage publications, collaborate on manuscripts, and track their academic profile
- **Research Administrators** to oversee institutional research activities and outputs
- **Funding Foundations** to manage grants, campaigns, and track research impact

## Features

### AI-Powered Insights

- **AI Publication Summaries**: Automatically generate comprehensive summaries of research publications using Google Gemini AI
- **Keyword Extraction**: AI-powered extraction of key terms and concepts from abstracts
- **Batch Processing**: Generate summaries for multiple publications simultaneously
- **Research Trends**: Identify emerging patterns and themes in your research portfolio

### Publication Management

- **Multi-Source Import**: Import from PubMed, CrossRef, OpenAlex, and Research4Life
- **Format Support**: BibTeX, RIS (EndNote), Mendeley, and CSV formats
- **Folder Organization**: Create custom hierarchies to organize your publications
- **Citation Styles**: Support for 7 major styles (APA, MLA, Chicago, Harvard, Vancouver, IEEE, AMA)
- **Citation Tracking**: Track citations with metadata using custom TipTap extension
- **Hover Menu**: Quick update/delete citations with inline hover menu
- **Bibliography Generation**: Automatic bibliography with only cited references
- **Cite-as-You-Write**: Real-time citation insertion while writing

### Manuscript Collaboration

- **Real-time Editing**: Collaborative document editing with TipTap rich text editor
- **ORCID Integration**: Invite collaborators via ORCID search or direct email
- **Role-Based Permissions**: Owner, Admin, Editor, Contributor, Reviewer roles
- **Track Changes**: Accept/reject workflow for document revisions
- **Version History**: Manual and automatic snapshots with restore capability
- **Comments & Suggestions**: Threaded comments and inline suggestions
- **Presence Indicators**: See who's online and editing in real-time
- **Citation Management**: Integrated citation insertion and bibliography generation

### Research Proposals

- **Structured Templates**: Create proposals with predefined sections
- **Publication Linking**: Connect related publications and manuscripts
- **Ethics Tracking**: Track ethical approvals and documentation
- **Budget Management**: Manage project budgets and funding sources
- **Milestone Tracking**: Monitor deliverables and project progress
- **Multi-Investigator**: Support for collaborative research teams
- **Data Management Plans**: Create and manage DMP documents

### Network Visualization

- **Collaboration Network**: Interactive D3.js visualization of research connections
- **ORCID Display**: Show researcher ORCID IDs in network profiles
- **Citation Metrics**: Display global citations and HospitiumRIS citations
- **Force-Directed Layout**: Automatic node positioning with collision detection
- **Relationship Levels**: Direct, secondary, and tertiary collaboration visualization
- **Publication Sharing**: View shared publications between collaborators

### Analytics & Reporting

- **Research Analytics**: Professional bar charts with proper scaling
- **Publication Trends**: Track publications and projects over time
- **Citation Impact**: Monitor citation counts and h-index
- **Network Growth**: Visualize collaboration network expansion
- **Custom Reports**: Generate reports for specific time periods
- **Export Options**: Download data in multiple formats

### Integrations

- **ORCID**: Authentication and researcher profile lookup
- **Zotero**: Library synchronization and import
- **DOI Resolution**: Automatic metadata fetching via DOI
- **PubMed**: Direct search and import from PubMed database
- **OpenAlex**: Access to open scholarly data
- **CrossRef**: Citation data and metadata retrieval
- **Research4Life**: Access to research resources

### Grant & Campaign Management

- **Funding Tracking**: Monitor grant opportunities and applications
- **Campaign Management**: Manage fundraising campaigns with activity logs
- **Donor Records**: Track donations and donor information
- **Budget Allocation**: Manage research budgets and expenses
- **Reporting**: Generate financial and progress reports

## Tech Stack

- **Framework**: Next.js 16 with React 19
- **Database**: PostgreSQL with Prisma ORM
- **UI**: Material UI (MUI) 7
- **Editor**: TipTap rich text editor
- **Visualization**: D3.js and Chart.js

## Getting Started

### Prerequisites

- Node.js 20 or later
- PostgreSQL 14 or later

### Docker (recommended for production)

Run the full stack (PostgreSQL + Next.js + Nginx) with Docker:

```bash
cp .env.docker.example .env
# Edit .env — set POSTGRES_PASSWORD, NEXTAUTH_SECRET, GLOBAL_ADMIN_*
docker compose up -d --build
```

Open http://localhost after containers are healthy.

For development with hot reload:

```bash
docker compose -f docker-compose.dev.yml up --build
```

See [docs/DOCKER_DEPLOYMENT.md](docs/DOCKER_DEPLOYMENT.md) for SSL, backups, scaling, and troubleshooting.

Production CI/CD (GitHub Actions → VPS, frontend + Prisma migrations) is documented in [docs/CI_CD.md](docs/CI_CD.md).

### Installation

1. Clone the repository and install dependencies:

```bash
npm install
```

2. Create a `.env` file with your configuration:

```env
DATABASE_URL="postgresql://username:password@localhost:5432/hospitiumris"
NEXTAUTH_SECRET="your-secret-key-at-least-32-characters"
NEXT_PUBLIC_APP_URL="http://localhost:3000"

# SMTP Configuration
SMTP_HOST="smtp.gmail.com"
SMTP_PORT="587"
SMTP_SECURE="false"
SMTP_USER="your-email@gmail.com"
SMTP_PASS="your-app-password"
FROM_EMAIL="HospitiumRIS <your-email@gmail.com>"

# ORCID (optional)
NEXT_PUBLIC_ORCID_CLIENT_ID="your-client-id"
ORCID_CLIENT_SECRET="your-client-secret"
NEXT_PUBLIC_ORCID_REDIRECT_URI="http://localhost:3000/auth/orcid/callback"

# Google Gemini AI (optional - for AI summaries)
GOOGLE_GEMINI_API_KEY="your-gemini-api-key"
```

3. Set up the database:

```bash
npm run db:generate
npm run db:push
```

4. **IMPORTANT**: Seed the account types (required before first run):

```bash
node prisma/seed-account-types.js
```

This creates the necessary account type records (GLOBAL_ADMIN, RESEARCHER, RESEARCH_ADMIN, etc.) in the database. Without this step, user creation will fail with a foreign key constraint error.

5. Start the development server:

```bash
npm run dev
```

On first run, you'll be prompted to create a **Global Admin** account interactively. This account has full system access and can create institution admins. The setup will ask for:
- Full name
- Email address
- Password (minimum 8 characters)

After creation, you can access:
- Login: [http://localhost:3000/login](http://localhost:3000/login)
- Global Admin Panel: [http://localhost:3000/global-admin](http://localhost:3000/global-admin)

## Available Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Start development server with Turbopack |
| `npm run build` | Build for production |
| `npm run start` | Start production server |
| `npm run db:generate` | Generate Prisma client |
| `npm run db:push` | Push schema changes to database |
| `npm run db:migrate` | Run database migrations |
| `npm run db:studio` | Open Prisma Studio database browser |
| `npm run db:seed` | Seed database with sample data |
| `npm run test:email` | Test SMTP email configuration |
| `npm run docker:prod` | Start production Docker stack (nginx + app + postgres) |
| `npm run docker:dev` | Start development Docker stack with hot reload |
| `npm run docker:build` | Build Docker images |
| `npm run docker:down` | Stop Docker containers |
| `npm run docker:logs` | View application container logs |
| `npm run docker:clean` | Remove containers, volumes, and local images |

## Project Structure

```
src/
├── app/                    # Next.js App Router pages and API routes
│   ├── api/               # REST API endpoints
│   ├── researcher/        # Researcher dashboard pages
│   ├── institution/       # Institution admin pages
│   └── foundation/        # Foundation admin pages
├── components/            # Reusable React components
├── lib/                   # Core utilities and configuration
├── services/              # External API integrations
└── utils/                 # Helper functions
```

## Troubleshooting

### Foreign Key Constraint Error on First Run

If you encounter an error like `Foreign key constraint violated on the constraint: users_accountType_fkey` when starting the application:

1. Ensure PostgreSQL is running
2. Verify your `DATABASE_URL` in `.env` is correct
3. Run the account types seed script:
   ```bash
   node prisma/seed-account-types.js
   ```
4. Try starting the application again with `npm run dev`

### Database Connection Issues

- Check that PostgreSQL service is running
- Verify database credentials in `.env`
- Ensure the database exists: `createdb hospitiumris`
- Test connection with: `npx prisma db pull`

### Email Configuration Issues

- For Gmail, use an App Password instead of your regular password
- Enable "Less secure app access" or use OAuth2
- Test your configuration with: `npm run test:email`

## CI / production deploy

A push to `main` builds the app on GitHub, SSHs into the VPS at `/opt/hospitium`, rebuilds the frontend container, and runs Prisma migrations. Postgres stays up.

Full step-by-step setup (SSH keys, GitHub environment secrets, workflow diagram, how to verify migrations, listing users): **[docs/CI_CD.md](docs/CI_CD.md)**.

## Documentation

Additional documentation is available in the `docs/` directory:

- [CI/CD (GitHub Actions → production VPS)](docs/CI_CD.md) — step-by-step SSH secrets, deploy workflow, database migrations, and server commands
- [Docker deployment](docs/DOCKER_DEPLOYMENT.md) — Compose, volumes, SSL, backups
- `DATABASE_SETUP.md` - Database configuration guide
- `ORCID_SETUP_GUIDE.md` - ORCID integration setup
- `ZOTERO_SETUP.md` - Zotero synchronization guide
- `MENDELEY_IMPORT_GUIDE.md` - Importing from Mendeley

## License

This project is proprietary software. All rights reserved.
