'use client';

import React, { useState, useEffect } from 'react';
import {
  Box,
  Container,
  Paper,
  Typography,
  Button,
  Stepper,
  Step,
  StepLabel,
  Card,
  CardContent,
  Alert,
  CircularProgress,
  Fade,
} from '@mui/material';
import {
  CheckCircle as CheckCircleIcon,
  ArrowForward as ArrowForwardIcon,
  ArrowBack as ArrowBackIcon,
} from '@mui/icons-material';
import { useTheme } from '@mui/material/styles';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { useThemeMode } from '../../components/ThemeProvider';
import dynamic from 'next/dynamic';
import { useTranslation } from 'react-i18next';

// Dynamic imports for step components with loading fallbacks
const AccountTypeStep = dynamic(() => import('../../components/Registration/AccountTypeStep'), {
  loading: () => <RegistrationStepSkeleton />
});

const OrcidSearchStep = dynamic(() => import('../../components/Registration/OrcidSearchStep'), {
  loading: () => <RegistrationStepSkeleton />
});

const AccountDetailsStep = dynamic(() => import('../../components/Registration/AccountDetailsStep'), {
  loading: () => <RegistrationStepSkeleton />
});

const PasswordStep = dynamic(() => import('../../components/Registration/PasswordStep'), {
  loading: () => <RegistrationStepSkeleton />
});

const FoundationAdminStep = dynamic(() => import('../../components/Registration/FoundationAdminStep'), {
  loading: () => <RegistrationStepSkeleton />
});

// Loading skeleton component for registration steps
const RegistrationStepSkeleton = () => (
  <Box sx={{ p: 3, minHeight: 200 }}>
    <Box sx={{ 
      width: '60%', 
      height: 32, 
      bgcolor: 'grey.200', 
      borderRadius: 1, 
      mb: 2, 
      mx: 'auto',
      animation: 'pulse 1.5s ease-in-out infinite'
    }} />
    <Box sx={{ mb: 3 }}>
      <Box sx={{ 
        width: '100%', 
        height: 56, 
        bgcolor: 'grey.100', 
        borderRadius: 1, 
        mb: 2,
        animation: 'pulse 1.5s ease-in-out infinite'
      }} />
      <Box sx={{ 
        width: '100%', 
        height: 56, 
        bgcolor: 'grey.100', 
        borderRadius: 1, 
        mb: 2,
        animation: 'pulse 1.5s ease-in-out infinite'
      }} />
      <Box sx={{ 
        width: '100%', 
        height: 56, 
        bgcolor: 'grey.100', 
        borderRadius: 1,
        animation: 'pulse 1.5s ease-in-out infinite'
      }} />
    </Box>
  </Box>
);

// NoSSR wrapper component to prevent hydration mismatch
const NoSSR = ({ children, fallback = null }) => {
  const [hasMounted, setHasMounted] = useState(false);

  useEffect(() => {
    setHasMounted(true);
  }, []);

  if (!hasMounted) {
    return fallback;
  }

  return children;
};

const RESEARCH_ADMIN_ACCOUNT_NAME = 'Research Administrator';

const RegisterPage = () => {
  const theme = useTheme();
  const router = useRouter();
  const { isDarkMode, isClient } = useThemeMode();
  const { t, i18n } = useTranslation();
  
  // Multi-step form state
  const [activeStep, setActiveStep] = useState(0);
  const [accountType, setAccountType] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [selectedOrcidProfile, setSelectedOrcidProfile] = useState(null);
  const [inviteDetails, setInviteDetails] = useState(null);

  // Form data state
  const [formData, setFormData] = useState({
    // Account type
    accountType: '',
    
    // Personal details
    givenName: '',
    familyName: '',
    email: '',
    confirmEmail: '',
    password: '',
    confirmPassword: '',
    
    // ORCID data
    orcidId: '',
    orcidGivenNames: '',
    orcidFamilyName: '',
    isOrcidRegistration: false, // Flag for ORCID-initiated registration
    
    // Researcher specific
    primaryInstitution: '',
    startMonth: '',
    startYear: '',
    
    // Research Admin specific
    accountName: '',
    matchedInstitutionId: '',
    institutionName: '',
    institutionType: '',
    institutionCountry: '',
    institutionWebsite: '',
    
    // Foundation Admin specific
    foundationName: '',
    foundationType: '',
    foundationCountry: '',
    foundationFocusArea: '',
    foundationWebsite: '',
    foundationDescription: '',
  });

  // Handle ORCID registration from callback and collaboration invite links
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const isOrcidLogin = urlParams.get('orcid') === 'true';
    const inviteToken = urlParams.get('invite');
    
    if (isOrcidLogin) {
      console.log('🔗 ORCID registration detected - user will need to complete registration');
      setFormData(prev => ({
        ...prev,
        isOrcidRegistration: true
      }));
      
      // Clean up URL
      window.history.replaceState({}, document.title, window.location.pathname);
    }

    if (inviteToken) {
      fetch(`/api/manuscripts/invitations/token/${encodeURIComponent(inviteToken)}`)
        .then((res) => res.json())
        .then((data) => {
          if (!data.success || !data.data) {
            setFormError(data.error || 'This invitation link is invalid.');
            return;
          }
          if (data.data.expired) {
            setFormError('This collaboration invitation has expired or already been used.');
            return;
          }
          setInviteDetails(data.data);
          setAccountType('RESEARCHER');
          setFormData(prev => ({
            ...prev,
            accountType: 'RESEARCHER',
            email: data.data.email || prev.email,
            confirmEmail: data.data.email || prev.confirmEmail,
            givenName: data.data.givenName || prev.givenName,
            familyName: data.data.familyName || prev.familyName,
          }));
        })
        .catch((error) => {
          console.error('Failed to load invitation:', error);
        });
    }
  }, []);

  // Define steps based on account type
  const getSteps = () => {
    const baseSteps = [t('auth.step_account_type')];
    
    if (accountType === 'RESEARCHER') {
      return [...baseSteps, t('auth.step_orcid_search'), t('auth.step_account_details'), t('auth.step_password')];
    } else if (accountType === 'RESEARCH_ADMIN') {
      return [...baseSteps, t('auth.step_account_details'), t('auth.step_password')];
    } else if (accountType === 'FOUNDATION_ADMIN') {
      return [...baseSteps, t('auth.step_email_password')];
    } else if (accountType === 'OPERATIONS') {
      return [...baseSteps, t('auth.step_email_password')];
    }
    
    return baseSteps;
  };

  const steps = getSteps();

  // Generate month options
  const monthOptions = React.useMemo(() => [
    { value: '01', label: t('auth.month_january') },
    { value: '02', label: t('auth.month_february') },
    { value: '03', label: t('auth.month_march') },
    { value: '04', label: t('auth.month_april') },
    { value: '05', label: t('auth.month_may') },
    { value: '06', label: t('auth.month_june') },
    { value: '07', label: t('auth.month_july') },
    { value: '08', label: t('auth.month_august') },
    { value: '09', label: t('auth.month_september') },
    { value: '10', label: t('auth.month_october') },
    { value: '11', label: t('auth.month_november') },
    { value: '12', label: t('auth.month_december') },
  ], [t, i18n.language]);

  // Generate year options (current year back to 1950)
  const currentYear = new Date().getFullYear();
  const yearOptions = [];
  for (let year = currentYear; year >= 1950; year--) {
    yearOptions.push({ value: year.toString(), label: year.toString() });
  }

  // Handle input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  // Handle account type selection
  const handleAccountTypeChange = (event, newAccountType) => {
    if (newAccountType !== null) {
      setAccountType(newAccountType);
      setFormData(prev => ({
        ...prev,
        accountType: newAccountType,
        ...(newAccountType === 'RESEARCH_ADMIN'
          ? { accountName: RESEARCH_ADMIN_ACCOUNT_NAME }
          : {}),
      }));
      // Clear account type error when user makes a selection
      if (errors.accountType) {
        setErrors(prev => ({ ...prev, accountType: '' }));
      }
    }
  };

  // Handle ORCID profile selection
  const handleOrcidSelect = (profile) => {
    setSelectedOrcidProfile(profile);
    setFormData(prev => ({
      ...prev,
      orcidId: profile['orcid-id'],
      orcidGivenNames: profile['given-names'],
      orcidFamilyName: profile['family-names'],
      givenName: profile['given-names'],
      familyName: profile['family-names'],
      primaryInstitution: profile['institution-name'].length > 0 ? profile['institution-name'][0] : ''
    }));
  };


  // Validation functions
  const validateEmail = (email) => {
    const re = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
    return re.test(email);
  };

  const verifyEmailDomain = async (email) => {
    const response = await fetch('/api/auth/verify-email-domain', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email }),
    });
    return response.json();
  };

  const validatePassword = (password) => {
    const minLength = password.length >= 8;
    const hasUpper = /[A-Z]/.test(password);
    const hasLower = /[a-z]/.test(password);
    const hasNumber = /\d/.test(password);
    const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    
    return {
      isValid: minLength && hasUpper && hasLower && hasNumber && hasSpecial,
      requirements: {
        minLength,
        hasUpper,
        hasLower,
        hasNumber,
        hasSpecial,
      }
    };
  };

  const validateResearcherAccountDetails = (newErrors) => {
    if (!formData.givenName.trim()) {
      newErrors.givenName = t('auth.error_given_name_required');
    }
    if (!formData.familyName.trim()) {
      newErrors.familyName = t('auth.error_family_name_required');
    }
    if (!formData.email) {
      newErrors.email = t('auth.error_email_required');
    } else if (!validateEmail(formData.email)) {
      newErrors.email = t('auth.error_email_invalid');
    }
    if (!formData.primaryInstitution.trim()) {
      newErrors.primaryInstitution = t('auth.error_institution_required');
    }
    if (!formData.startMonth) {
      newErrors.startMonth = t('auth.error_start_month_required');
    }
    if (!formData.startYear) {
      newErrors.startYear = t('auth.error_start_year_required');
    }
  };

  const validateResearchAdminAccountDetails = async (newErrors) => {
    if (!formData.email) {
      newErrors.email = t('auth.error_email_required');
    } else if (!validateEmail(formData.email)) {
      newErrors.email = t('auth.error_email_invalid');
    } else {
      try {
        const domainCheck = await verifyEmailDomain(formData.email);
        if (!domainCheck.valid) {
          newErrors.email = domainCheck.message || t('auth.error_email_verified_domain');
        } else if (!domainCheck.institutionId) {
          newErrors.email = t(
            'auth.error_institution_not_detected',
            'Please verify your institutional email to detect your institution'
          );
        } else {
          handleInstitutionMatched({
            institutionId: domainCheck.institutionId,
            institutionName: domainCheck.institutionName,
          });
        }
      } catch (error) {
        newErrors.email = t('auth.error_email_verified_domain');
      }
    }
  };

  const validatePasswordFields = (newErrors) => {
    if (!formData.password) {
      newErrors.password = t('auth.error_password_required');
    } else {
      const validation = validatePassword(formData.password);
      if (!validation.isValid) {
        newErrors.password = t('auth.error_password_weak');
      }
    }
    if (!formData.confirmPassword) {
      newErrors.confirmPassword = t('auth.error_confirm_password_required');
    } else if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = t('auth.error_passwords_mismatch');
    }
  };

  const handleInstitutionMatched = (match) => {
    if (!match) {
      setFormData(prev => ({
        ...prev,
        matchedInstitutionId: '',
        primaryInstitution: '',
        institutionName: '',
      }));
      return;
    }
    setFormData(prev => ({
      ...prev,
      matchedInstitutionId: match.institutionId || '',
      primaryInstitution: match.institutionName || '',
      institutionName: match.institutionName || '',
    }));
    setErrors(prev => ({ ...prev, email: '' }));
  };

  // Step validation
  const validateStep = async (step) => {
    const newErrors = {};

    if (step === 0) {
      if (!formData.accountType) {
        newErrors.accountType = t('auth.error_account_type_required');
      }
      setErrors(newErrors);
      return Object.keys(newErrors).length === 0;
    }

    if (accountType === 'FOUNDATION_ADMIN' || accountType === 'OPERATIONS') {
      if (!formData.email) {
        newErrors.email = t('auth.error_email_required');
      } else if (!validateEmail(formData.email)) {
        newErrors.email = t('auth.error_email_invalid');
      } else if (accountType === 'FOUNDATION_ADMIN') {
        try {
          const domainCheck = await verifyEmailDomain(formData.email);
          if (!domainCheck.valid) {
            newErrors.email = domainCheck.message || t('auth.error_email_verified_domain');
          }
        } catch (error) {
          newErrors.email = t('auth.error_email_verified_domain');
        }
      }
      validatePasswordFields(newErrors);
    } else if (accountType === 'RESEARCH_ADMIN') {
      if (step === 1) await validateResearchAdminAccountDetails(newErrors);
      if (step === 2) validatePasswordFields(newErrors);
    } else if (accountType === 'RESEARCHER') {
      if (step === 1 && !selectedOrcidProfile) {
        newErrors.orcidSearch = t('auth.error_orcid_required');
      }
      if (step === 2) validateResearcherAccountDetails(newErrors);
      if (step === 3) validatePasswordFields(newErrors);
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Navigation handlers
  const handleNext = async () => {
    if (await validateStep(activeStep)) {
      setActiveStep(prev => prev + 1);
    }
  };

  const handleBack = () => {
    setActiveStep(prev => prev - 1);
  };

  // Submit handler
  const handleSubmit = async () => {
    setIsLoading(true);
    setFormError('');

    if (!(await validateStep(activeStep))) {
      setIsLoading(false);
      return;
    }
    
    try {
      const requestBody = {
        ...formData,
        // Ensure all necessary fields are included
        accountType: formData.accountType,
        accountName: accountType === 'RESEARCH_ADMIN'
          ? RESEARCH_ADMIN_ACCOUNT_NAME
          : formData.accountName,
        givenName: formData.givenName,
        familyName: formData.familyName,
        email: formData.email,
        confirmEmail: formData.confirmEmail,
        password: formData.password,
        confirmPassword: formData.confirmPassword,
        
        // ORCID data
        orcidId: formData.orcidId,
        orcidGivenNames: formData.orcidGivenNames,
        orcidFamilyName: formData.orcidFamilyName,
        
        // Research details
        primaryInstitution: formData.primaryInstitution,
        startMonth: formData.startMonth,
        startYear: formData.startYear,
        
        // Institution details
        institutionName: formData.institutionName,
        institutionType: formData.institutionType,
        institutionCountry: formData.institutionCountry,
        institutionWebsite: formData.institutionWebsite,
        
        // Foundation details
        foundationName: formData.foundationName,
        foundationType: formData.foundationType,
        foundationCountry: formData.foundationCountry,
        foundationWebsite: formData.foundationWebsite,
        foundationFocusArea: formData.foundationFocusArea,
        foundationDescription: formData.foundationDescription,
      };

      console.log('Submitting registration with data:', requestBody);

      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
      });

      const data = await response.json();

      if (data.success) {
        console.log('Registration successful:', data);
        
        // Redirect to success page with login prompt
        setFormError('');
        router.push(
          '/register/success?email=' + encodeURIComponent(formData.email) +
          (inviteDetails ? '&next=' + encodeURIComponent('/researcher/publications/collaborate') : '')
        );
      } else {
        // Handle validation errors from server
        console.log('Registration failed:', data);
        console.log('Validation errors:', data.errors);
        if (data.errors) {
          setErrors(data.errors);
          
          // If there are step-specific errors, go back to the relevant step
          const errorKeys = Object.keys(data.errors);
          if (errorKeys.some(key => ['accountType'].includes(key))) {
            setActiveStep(0);
          } else if (accountType === 'FOUNDATION_ADMIN' || accountType === 'OPERATIONS') {
            if (errorKeys.some(key => ['email', 'password', 'confirmPassword'].includes(key))) {
              setActiveStep(1);
            }
          } else if (accountType === 'RESEARCH_ADMIN') {
            if (errorKeys.some(key => ['accountName', 'email', 'confirmEmail', 'primaryInstitution'].includes(key))) {
              setActiveStep(1);
            } else if (errorKeys.some(key => ['password', 'confirmPassword'].includes(key))) {
              setActiveStep(2);
            }
          } else {
            if (errorKeys.some(key => ['orcidSearch'].includes(key))) {
              setActiveStep(1);
            } else if (errorKeys.some(key => ['givenName', 'familyName', 'email', 'confirmEmail', 'primaryInstitution', 'startMonth', 'startYear'].includes(key))) {
              setActiveStep(2);
            } else if (errorKeys.some(key => ['password', 'confirmPassword'].includes(key))) {
              setActiveStep(3);
            }
          }
        }
        
        setFormError(data.message || t('errors.server_error'));
      }
      
    } catch (error) {
      console.error('Registration error:', error);
      setFormError(t('errors.network_error'));
    } finally {
      setIsLoading(false);
    }
  };

  // Step content renderer
  const renderStepContent = (step) => {
    switch (step) {
      case 0: // Account Type Selection
        return (
          <AccountTypeStep 
            accountType={formData.accountType}
            onAccountTypeChange={handleAccountTypeChange}
            errors={errors}
            onNext={handleNext}
          />
        );

      case 1: 
        if (accountType === 'FOUNDATION_ADMIN' || accountType === 'OPERATIONS') {
          return (
            <FoundationAdminStep 
              formData={formData}
              onInputChange={handleInputChange}
              errors={errors}
              accountType={accountType}
            />
          );
        }
        if (accountType === 'RESEARCH_ADMIN') {
          return (
            <AccountDetailsStep 
              formData={formData}
              onInputChange={handleInputChange}
              onInstitutionMatched={handleInstitutionMatched}
              errors={errors}
              accountType={accountType}
              emailLocked={!!inviteDetails?.email}
            />
          );
        }
        return (
          <OrcidSearchStep 
            onOrcidSelect={handleOrcidSelect}
            selectedOrcidProfile={selectedOrcidProfile}
            errors={errors}
          />
        );
        
      case 2: 
        if (accountType === 'RESEARCH_ADMIN') {
          return (
            <PasswordStep 
              formData={formData}
              onInputChange={handleInputChange}
              errors={errors}
            />
          );
        }
        return (
          <AccountDetailsStep 
            formData={formData}
            onInputChange={handleInputChange}
            errors={errors}
            accountType={accountType}
            monthOptions={monthOptions}
            yearOptions={yearOptions}
            emailLocked={!!inviteDetails?.email}
          />
        );

      case 3: 
        if (accountType === 'RESEARCHER') {
          return (
            <PasswordStep 
              formData={formData}
              onInputChange={handleInputChange}
              errors={errors}
            />
          );
        }
        break;

      default:
        return null;
    }
  };

  return (
    <Box
      sx={{
        minHeight: 'calc(100vh - 7.5rem)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: theme.palette.background.default,
        py: { xs: 3, sm: 4 },
      }}
    >
      <Container maxWidth="lg">
        <Paper
          elevation={0}
          sx={{
            p: { xs: 2, sm: 3 },
            backgroundColor: theme.palette.background.paper,
            border: `1px solid ${theme.palette.mode === 'dark' ? '#404040' : 'rgba(0,0,0,0.1)'}`,
            maxWidth: 1000,
            mx: 'auto',
          }}
        >
          {/* Logo and Title */}
          <Box sx={{ textAlign: 'center', mb: 3 }}>
            <Image
              src="/hospitium-logo.png"
              alt="Hospitium RIS"
              width={140}
              height={32}
              style={{ marginBottom: '12px' }}
              priority
            />
            <Typography
              variant="h4"
              component="h1"
              sx={{
                fontWeight: 600,
                color: theme.palette.text.primary,
                mb: 0.5,
                fontSize: { xs: '1.75rem', sm: '2rem' },
              }}
            >
              {t('auth.register_title')}
            </Typography>
            <Typography
              variant="body2"
              color="text.secondary"
              sx={{ fontSize: '0.875rem' }}
            >
              {t('auth.register_subtitle')}
            </Typography>
          </Box>

          {/* Stepper */}
          <Box sx={{ mb: 3 }}>
            <Stepper activeStep={activeStep} alternativeLabel>
              {steps.map((label) => (
                <Step key={label}>
                  <StepLabel 
                    sx={{
                      '& .MuiStepLabel-label': {
                        fontSize: { xs: '0.75rem', sm: '0.875rem' },
                      },
                    }}
                  >
                    {label}
                  </StepLabel>
                </Step>
              ))}
            </Stepper>
          </Box>

          {/* Error Alert */}
          {formError && (
            <Alert severity="error" sx={{ mb: 2 }}>
              {formError}
            </Alert>
          )}

          {inviteDetails && !inviteDetails.expired && (
            <Alert severity="info" sx={{ mb: 2 }}>
              {inviteDetails.inviterName} invited you to collaborate on &ldquo;{inviteDetails.manuscriptTitle}&rdquo;.
              Create an account with {inviteDetails.email} to accept the invitation after you log in.
            </Alert>
          )}

          {/* Form Content */}
          <Card elevation={0} sx={{ mb: 3, border: `1px solid ${theme.palette.divider}` }}>
            <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
              <Fade in={true} key={activeStep}>
                <Box sx={{ minHeight: 200 }}>
                  {renderStepContent(activeStep)}
                </Box>
              </Fade>
            </CardContent>
          </Card>

          {/* Navigation Buttons */}
          <Box sx={{ display: 'flex', justifyContent: 'space-between', gap: 2, mb: 2 }}>
            <Button
              onClick={handleBack}
              disabled={activeStep === 0}
              startIcon={<ArrowBackIcon />}
              sx={{ visibility: activeStep === 0 ? 'hidden' : 'visible' }}
            >
              {t('common.back')}
            </Button>

            <Button
              variant="contained"
              onClick={activeStep === steps.length - 1 ? handleSubmit : handleNext}
              disabled={isLoading}
              endIcon={
                isLoading ? (
                  <CircularProgress size={16} color="inherit" />
                ) : activeStep === steps.length - 1 ? (
                  <CheckCircleIcon />
                ) : (
                  <ArrowForwardIcon />
                )
              }
            >
              {isLoading ? t('common.loading') : activeStep === steps.length - 1 ? t('common.create') : t('common.next')}
            </Button>
          </Box>

          {/* Sign In Link */}
          <Box sx={{ textAlign: 'center' }}>
            <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.875rem' }}>
              {t('auth.have_account')}{' '}
              <Button
                variant="text"
                onClick={() => router.push('/login')}
                sx={{ textTransform: 'none', p: 0, minWidth: 'auto', fontSize: '0.875rem' }}
              >
                {t('auth.sign_in')}
              </Button>
            </Typography>
          </Box>
        </Paper>
      </Container>
    </Box>
  );
};

export default RegisterPage; 