import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { getUserId } from '../../../../../../lib/auth-server.js';

const prisma = new PrismaClient();

/**
 * Update collaborator role and permissions
 * PATCH /api/manuscripts/[manuscriptId]/collaborators/[collaboratorId]
 */
export async function PATCH(request, { params }) {
  try {
    const userId = await getUserId();
    if (!userId) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    // In Next.js 15+, params is a Promise
    const resolvedParams = await params;
    const { manuscriptId, collaboratorId } = resolvedParams;
    const updateData = await request.json();

    if (!manuscriptId || !collaboratorId) {
      return NextResponse.json(
        { error: 'Manuscript ID and Collaborator ID are required' },
        { status: 400 }
      );
    }

    // Verify user has permission to manage collaborators (owner or admin with invite permission)
    const manuscript = await prisma.manuscript.findFirst({
      where: {
        id: manuscriptId,
        OR: [
          { createdBy: userId },
          {
            collaborators: {
              some: {
                userId: userId,
                OR: [
                  { role: 'OWNER' },
                  { role: 'ADMIN', canInvite: true }
                ]
              }
            }
          }
        ]
      }
    });

    if (!manuscript) {
      return NextResponse.json(
        { error: 'Manuscript not found or insufficient permissions' },
        { status: 404 }
      );
    }

    // Get the collaborator to update
    const collaborator = await prisma.manuscriptCollaborator.findFirst({
      where: {
        id: collaboratorId,
        manuscriptId
      },
      include: {
        user: true
      }
    });

    if (!collaborator) {
      return NextResponse.json(
        { error: 'Collaborator not found' },
        { status: 404 }
      );
    }

    // Prevent changing the owner's role
    if (collaborator.role === 'OWNER' && updateData.role !== 'OWNER') {
      return NextResponse.json(
        { error: 'Cannot change the role of the manuscript owner' },
        { status: 403 }
      );
    }

    // Prevent removing yourself if you're the owner
    if (collaborator.userId === userId && collaborator.role === 'OWNER') {
      return NextResponse.json(
        { error: 'Owner cannot modify their own role' },
        { status: 403 }
      );
    }

    // Convert role to uppercase to match Prisma enum (Admin -> ADMIN)
    const normalizedRole = updateData.role 
      ? updateData.role.toUpperCase() 
      : collaborator.role;

    // Track what changed for notification
    const roleChanged = normalizedRole !== collaborator.role;
    const permissionsChanged = 
      (updateData.canEdit !== undefined && updateData.canEdit !== collaborator.canEdit) ||
      (updateData.canInvite !== undefined && updateData.canInvite !== collaborator.canInvite) ||
      (updateData.canDelete !== undefined && updateData.canDelete !== collaborator.canDelete);

    // Update the collaborator
    const updatedCollaborator = await prisma.manuscriptCollaborator.update({
      where: {
        id: collaboratorId
      },
      data: {
        role: normalizedRole,
        canEdit: updateData.canEdit !== undefined ? updateData.canEdit : collaborator.canEdit,
        canInvite: updateData.canInvite !== undefined ? updateData.canInvite : collaborator.canInvite,
        canDelete: updateData.canDelete !== undefined ? updateData.canDelete : collaborator.canDelete,
        updatedAt: new Date()
      },
      include: {
        user: {
          select: {
            id: true,
            givenName: true,
            familyName: true,
            email: true,
            orcidId: true,
            primaryInstitution: true
          }
        }
      }
    });

    // Create notification for the updated user (if not updating yourself and something changed)
    if (collaborator.userId !== userId && (roleChanged || permissionsChanged)) {
      // Build detailed message about what changed
      let changeDetails = [];
      
      if (roleChanged) {
        changeDetails.push(`Role changed to ${normalizedRole}`);
      }
      
      if (permissionsChanged) {
        const newPerms = [];
        if (updateData.canEdit !== undefined && updateData.canEdit !== collaborator.canEdit) {
          newPerms.push(`Can Edit: ${updateData.canEdit ? 'Enabled' : 'Disabled'}`);
        }
        if (updateData.canInvite !== undefined && updateData.canInvite !== collaborator.canInvite) {
          newPerms.push(`Can Invite: ${updateData.canInvite ? 'Enabled' : 'Disabled'}`);
        }
        if (updateData.canDelete !== undefined && updateData.canDelete !== collaborator.canDelete) {
          newPerms.push(`Can Delete: ${updateData.canDelete ? 'Enabled' : 'Disabled'}`);
        }
        if (newPerms.length > 0) {
          changeDetails.push(`Permissions updated: ${newPerms.join(', ')}`);
        }
      }

      await prisma.notification.create({
        data: {
          userId: collaborator.userId,
          manuscriptId,
          type: 'COLLABORATOR_ROLE_CHANGED',
          title: 'Role & Permissions Updated',
          message: `Your role and permissions in "${manuscript.title}" have been updated. ${changeDetails.join('. ')}`,
          priority: 'HIGH',
          data: {
            manuscriptTitle: manuscript.title,
            manuscriptId: manuscriptId,
            oldRole: collaborator.role,
            newRole: normalizedRole,
            permissions: {
              canEdit: updateData.canEdit !== undefined ? updateData.canEdit : collaborator.canEdit,
              canInvite: updateData.canInvite !== undefined ? updateData.canInvite : collaborator.canInvite,
              canDelete: updateData.canDelete !== undefined ? updateData.canDelete : collaborator.canDelete
            },
            updatedBy: userId,
            changes: changeDetails
          }
        }
      });
    }

    return NextResponse.json({
      success: true,
      data: updatedCollaborator,
      message: 'Collaborator updated successfully'
    });

  } catch (error) {
    console.error('Error updating collaborator:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  } finally {
    await prisma.$disconnect();
  }
}

/**
 * Remove collaborator from manuscript
 * DELETE /api/manuscripts/[manuscriptId]/collaborators/[collaboratorId]
 */
export async function DELETE(request, { params }) {
  try {
    const userId = await getUserId();
    if (!userId) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    // In Next.js 15+, params is a Promise
    const resolvedParams = await params;
    const { manuscriptId, collaboratorId } = resolvedParams;

    if (!manuscriptId || !collaboratorId) {
      return NextResponse.json(
        { error: 'Manuscript ID and Collaborator ID are required' },
        { status: 400 }
      );
    }

    // Verify user has permission to remove collaborators
    const manuscript = await prisma.manuscript.findFirst({
      where: {
        id: manuscriptId,
        OR: [
          { createdBy: userId },
          {
            collaborators: {
              some: {
                userId: userId,
                OR: [
                  { role: 'OWNER' },
                  { role: 'ADMIN', canInvite: true }
                ]
              }
            }
          }
        ]
      }
    });

    if (!manuscript) {
      return NextResponse.json(
        { error: 'Manuscript not found or insufficient permissions' },
        { status: 404 }
      );
    }

    // Get the collaborator to remove
    const collaborator = await prisma.manuscriptCollaborator.findFirst({
      where: {
        id: collaboratorId,
        manuscriptId
      },
      include: {
        user: true
      }
    });

    if (!collaborator) {
      return NextResponse.json(
        { error: 'Collaborator not found' },
        { status: 404 }
      );
    }

    // Prevent removing the owner
    if (collaborator.role === 'OWNER') {
      return NextResponse.json(
        { error: 'Cannot remove the manuscript owner' },
        { status: 403 }
      );
    }

    // Prevent removing yourself if you're the owner
    if (collaborator.userId === userId && collaborator.role === 'OWNER') {
      return NextResponse.json(
        { error: 'Owner cannot remove themselves' },
        { status: 403 }
      );
    }

    // Remove the collaborator
    await prisma.manuscriptCollaborator.delete({
      where: {
        id: collaboratorId
      }
    });

    // Create notification for the removed user (if not removing yourself)
    if (collaborator.userId !== userId) {
      await prisma.notification.create({
        data: {
          userId: collaborator.userId,
          manuscriptId,
          type: 'MANUSCRIPT_UPDATE',
          title: 'Removed from Manuscript',
          message: `You have been removed from the manuscript "${manuscript.title}"`,
          data: {
            manuscriptTitle: manuscript.title,
            removedBy: userId
          }
        }
      });
    }

    return NextResponse.json({
      success: true,
      message: 'Collaborator removed successfully'
    });

  } catch (error) {
    console.error('Error removing collaborator:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  } finally {
    await prisma.$disconnect();
  }
}
