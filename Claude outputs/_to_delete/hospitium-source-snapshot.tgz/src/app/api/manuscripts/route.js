import { NextResponse } from 'next/server';
import prisma from '../../../lib/prisma.js';
import { getUserId } from '../../../lib/auth-server.js';

export async function GET(request) {
    try {
        // Get authenticated user ID
        const userId = await getUserId(request);
        console.log('[Manuscripts API] Fetching manuscripts for user:', userId);
        
        if (!userId) {
            console.log('[Manuscripts API] No userId found, returning 401');
            return NextResponse.json(
                { error: 'Authentication required' },
                { status: 401 }
            );
        }

        const { searchParams } = new URL(request.url);
        const search = searchParams.get('search');
        const type = searchParams.get('type');
        const limit = parseInt(searchParams.get('limit')) || 20;
        const offset = parseInt(searchParams.get('offset')) || 0;

        // Build the where clause for filtering
        const where = {
            OR: [
                // User is the creator
                { createdBy: userId },
                // User is a collaborator
                {
                    collaborators: {
                        some: {
                            userId: userId
                        }
                    }
                }
            ]
        };

        // Add search filtering
        if (search) {
            where.AND = [
                {
                    OR: [
                        {
                            title: {
                                contains: search,
                                mode: 'insensitive'
                            }
                        },
                        {
                            description: {
                                contains: search,
                                mode: 'insensitive'
                            }
                        }
                    ]
                }
            ];
        }

        // Add type filtering
        if (type) {
            if (where.AND) {
                where.AND.push({ type: type });
            } else {
                where.AND = [{ type: type }];
            }
        }

        // Get manuscripts with filtering and pagination
        // Try to include lastUpdater, fall back if relation doesn't exist yet
        let manuscripts;
        try {
            manuscripts = await prisma.manuscript.findMany({
                where,
                orderBy: { updatedAt: 'desc' },
                take: limit,
                skip: offset,
                include: {
                    creator: {
                        select: {
                            id: true,
                            givenName: true,
                            familyName: true,
                            email: true,
                            orcidId: true
                        }
                    },
                    lastUpdater: {
                        select: {
                            id: true,
                            givenName: true,
                            familyName: true,
                            email: true
                        }
                    },
                    collaborators: {
                        select: {
                            user: {
                                select: {
                                    id: true,
                                    givenName: true,
                                    familyName: true,
                                    email: true,
                                    orcidId: true
                                }
                            },
                            role: true
                        }
                    },
                    invitations: {
                        where: { status: 'PENDING' },
                        select: {
                            id: true,
                            givenName: true,
                            familyName: true,
                            email: true,
                            role: true
                        }
                    }
                }
            });
        } catch (includeError) {
            // Fallback query without lastUpdater if the relation isn't available yet
            console.log('lastUpdater relation not available, using fallback query');
            manuscripts = await prisma.manuscript.findMany({
                where,
                orderBy: { updatedAt: 'desc' },
                take: limit,
                skip: offset,
                include: {
                    creator: {
                        select: {
                            id: true,
                            givenName: true,
                            familyName: true,
                            email: true,
                            orcidId: true
                        }
                    },
                    collaborators: {
                        select: {
                            user: {
                                select: {
                                    id: true,
                                    givenName: true,
                                    familyName: true,
                                    email: true,
                                    orcidId: true
                                }
                            },
                            role: true
                        }
                    },
                    invitations: {
                        where: { status: 'PENDING' },
                        select: {
                            id: true,
                            givenName: true,
                            familyName: true,
                            email: true,
                            role: true
                        }
                    }
                }
            });
        }

        // Get total count for pagination
        const totalCount = await prisma.manuscript.count({ where });

        // Transform the data to match the expected format
    const transformedManuscripts = manuscripts.map(manuscript => {
        // Process creator information
        const creatorName = manuscript.creator ? 
            `${manuscript.creator.givenName || ''} ${manuscript.creator.familyName || ''}`.trim() || manuscript.creator.email || 'Unknown Creator' : 
            'Unknown Creator';

        // Process collaborators (excluding creator if they're also in collaborators)
        // Filter out collaborators with null users (edge case when user is deleted)
        const processedCollaborators = (manuscript.collaborators || [])
            .filter(collab => collab && collab.user)
            .map(collab => {
                const user = collab.user;
                const fullName = `${user.givenName || ''} ${user.familyName || ''}`.trim() || user.email || 'Unknown User';
                return {
                    id: user.id,
                    name: fullName,
                    role: collab.role,
                    avatar: fullName.split(' ').map(n => n.charAt(0)).join('').toUpperCase().slice(0, 2),
                    isCreator: user.id === manuscript.createdBy
                };
            });

        // Determine current user's role and permissions
        const isOwner = manuscript.createdBy === userId;
        const currentUserCollaborator = (manuscript.collaborators || []).find(
            collab => collab.user && collab.user.id === userId
        );
        const currentUserRole = isOwner ? 'OWNER' : (currentUserCollaborator?.role || null);
        
        // Get individual permission flags from database (if user is a collaborator)
        // ADMIN role defaults: all permissions enabled
        const dbCanEdit = currentUserCollaborator?.canEdit ?? true;
        const dbCanInvite = currentUserCollaborator?.canInvite ?? (currentUserRole === 'ADMIN');
        const dbCanDelete = currentUserCollaborator?.canDelete ?? (currentUserRole === 'ADMIN');
        
        // Define permissions based on role AND individual permission flags
        // Owner always has all permissions
        // ADMIN has all permissions by default (can be customized)
        // For others, combine role-based defaults with individual permissions
        const canEdit = isOwner || (
            ['ADMIN', 'EDITOR', 'CONTRIBUTOR'].includes(currentUserRole) && dbCanEdit
        );
        const canManageTeam = isOwner || (
            currentUserRole === 'ADMIN' && dbCanInvite
        );
        const canDelete = isOwner || (
            currentUserRole === 'ADMIN' && dbCanDelete
        );

        // Process pending invitations
        const pendingInvitationsList = (manuscript.invitations || []).map(invitation => ({
            id: invitation.id,
            givenName: invitation.givenName,
            familyName: invitation.familyName,
            email: invitation.email,
            role: invitation.role || 'CONTRIBUTOR'
        }));

        // Process last updater info
        const lastUpdaterName = manuscript.lastUpdater ? 
            `${manuscript.lastUpdater.givenName || ''} ${manuscript.lastUpdater.familyName || ''}`.trim() || manuscript.lastUpdater.email || 'Unknown' : 
            null;

        return {
            ...manuscript,
            creator: {
                id: manuscript.creator?.id,
                name: creatorName,
                givenName: manuscript.creator?.givenName,
                familyName: manuscript.creator?.familyName,
                email: manuscript.creator?.email
            },
            lastUpdater: manuscript.lastUpdater ? {
                id: manuscript.lastUpdater.id,
                name: lastUpdaterName,
                givenName: manuscript.lastUpdater.givenName,
                familyName: manuscript.lastUpdater.familyName,
                email: manuscript.lastUpdater.email
            } : null,
            collaborators: processedCollaborators,
            pendingInvitationsList,
            pendingInvitations: pendingInvitationsList.length,
            authors: [creatorName, ...processedCollaborators.map(c => c.name)].join(', '),
            lastUpdated: manuscript.updatedAt?.toISOString() || new Date().toISOString(),
            collaboratorCount: processedCollaborators.length,
            totalCollaborators: processedCollaborators.length,
            // Current user's role and permissions
            currentUserRole,
            isOwner,
            permissions: {
                canEdit,
                canManageTeam,
                canDelete
            },
            // Individual permission flags from database (for displaying in UI)
            individualPermissions: currentUserCollaborator ? {
                canEdit: dbCanEdit,
                canInvite: dbCanInvite,
                canDelete: dbCanDelete
            } : null
        };
    });

    return NextResponse.json({
      success: true,
            manuscripts: transformedManuscripts,
            pagination: {
                total: totalCount,
                limit,
                offset,
                hasMore: offset + limit < totalCount
            }
    });

  } catch (error) {
    console.error('Error fetching manuscripts:', error);
    console.error('Error stack:', error.stack);
    return NextResponse.json(
            { error: 'Failed to fetch manuscripts', details: error.message },
      { status: 500 }
    );
    }
}

export async function POST(request) {
  try {
    const userId = await getUserId(request);
    if (!userId) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { title, type, field, description, keywords } = body;

    // Validate required fields
    if (!title || !type) {
      return NextResponse.json(
        { error: 'Title and type are required' },
        { status: 400 }
      );
    }

    // Create the manuscript
    const manuscript = await prisma.manuscript.create({
      data: {
        title: title.trim(),
        type: type,
        field: field?.trim() || null,
        description: description?.trim() || null,
        keywords: Array.isArray(keywords)
          ? keywords.map((k) => String(k).trim()).filter(Boolean)
          : [],
        status: 'DRAFT',
        createdBy: userId,
        content: '', // Initialize with empty content
        wordCount: 0
      },
      include: {
        creator: {
          select: {
            id: true,
            givenName: true,
            familyName: true,
            email: true,
            orcidId: true
          }
        },
        collaborators: {
          include: {
            user: {
              select: {
                id: true,
                givenName: true,
                familyName: true,
                email: true,
                orcidId: true
              }
            }
          }
        }
      }
    });

    // Transform the response to match expected format
    const transformedManuscript = {
      ...manuscript,
      authors: manuscript.collaborators
        .map(collab => {
          const user = collab.user;
          const fullName = `${user.givenName || ''} ${user.familyName || ''}`.trim();
          return fullName || user.email;
        })
        .join(', ') || 'Unknown',
      lastUpdated: manuscript.updatedAt.toISOString().split('T')[0],
      collaboratorCount: manuscript.collaborators.length
    };

    return NextResponse.json({
      success: true,
      data: {
        manuscript: transformedManuscript
      },
      message: 'Manuscript created successfully'
    });

  } catch (error) {
    console.error('Error creating manuscript:', error);
    return NextResponse.json(
      { error: 'Failed to create manuscript', details: error.message },
      { status: 500 }
    );
  }
}
